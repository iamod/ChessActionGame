﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissionUI : MonoBehaviour {

    public Text textPrefab;

	// Use this for initialization
	void Start () {
        Mission mission = MissionData.instance.mission;
        for (int i = 0; i < mission.whiteObjectives.Length; i++)
        {
            Text t = Instantiate(textPrefab, Vector3.zero, Quaternion.identity, transform);
            t.transform.localPosition = new Vector3(10, -40 - 20 * i, 0);
            t.text = mission.whiteObjectives[i].GetObjectiveDescription();
        }
	}
}
