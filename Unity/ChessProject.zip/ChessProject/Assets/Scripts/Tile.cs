﻿using UnityEngine;

public class Tile : MonoBehaviour {

    public Board board;
    public int x, y;
    public Unit unit;

    private MeshRenderer meshRenderer;
    private Color defaultColor;

    private void Awake()
    {
        meshRenderer = GetComponent<MeshRenderer>();
    }

    private void OnMouseUp()
    {
        board.TileClicked(this);
    }

    public void SetColor(Color color)
    {
        meshRenderer.material.color *= color;
    }

    public void ResetColor()
    {
        meshRenderer.material.color = defaultColor;
    }

    public void SetMaterial(Material material)
    {
        meshRenderer.material = Instantiate(material);
        defaultColor = meshRenderer.material.color;
    }

}