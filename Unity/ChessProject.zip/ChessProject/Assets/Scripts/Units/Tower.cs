﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : Unit {

    public override List<Move> GetMoves(Board board)
    {
        List<Move> moves = new List<Move>();

        Tile origin = board.GetTile(x, y);
        Tile t = null;
        Vector2 v2 = new Vector2(x, y);
        Vector2[] direction = { Vector2.up, Vector2.down, Vector2.left, Vector2.right };

        for (int i = 0; i < direction.Length; i++)
        {
            Vector2 v = v2;
            do
            {
                v += direction[i];
                t = board.GetTile((int)v.x, (int)v.y);
                if (t != null)
                {
                    if (t.unit == null)
                    {
                        Move m = new Move(t, Color.green);
                        m.AddMove(origin, t);
                        moves.Add(m);
                    }
                    else
                    {
                        if (t.unit.white != white)
                        {
                            Move m = new Move(t, Color.red);
                            m.AddMove(origin, t);
                            moves.Add(m);
                        }
                        t = null;
                    }
                }
            } while (t != null);
        }

        return moves;
    }

}
