﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class King : Unit
{

    public override List<Move> GetMoves(Board board)
    {
        List<Move> moves = new List<Move>();
        Tile origin = board.GetTile(x, y);
        Tile t = null;
        Vector2 v2 = new Vector2(x, y);

        for (int yy = -1; yy <= 1; yy++)
        {
            for (int xx = -1; xx <= 1; xx++)
            {
                if (xx == 0 && yy == 0)
                {
                    continue;
                }
                Vector2 v = v2 + new Vector2(xx, yy);
                t = board.GetTile((int)v.x, (int)v.y);
                if (t != null)
                {
                    if (t.unit == null)
                    {
                        Move m = new Move(t, Color.green);
                        m.AddMove(origin, t);
                        moves.Add(m);
                    }
                    else if (t.unit.white != white)
                    {
                        Move m = new Move(t, Color.red);
                        m.AddMove(origin, t);
                        moves.Add(m);
                    }
                }
            }
        }
        if (!hasMoved)
        {
            Debug.Log("King has not moved");
            for (int i = -1; i < 2; i += 2)
            {
                t = board.GetTile(origin.x + i, origin.y);
                if (t == null || t.unit != null)
                {
                    continue;
                }
                do
                {
                    t = board.GetTile(t.x + i, t.y);
                    if (t != null)
                    {
                        if (t.unit != null && t.unit is Tower && t.unit.white == white && !t.unit.hasMoved)
                        {
                            Tile t1 = board.GetTile(t.x - i, t.y);
                            Tile t2 = board.GetTile(t1.x - i, t.y);
                            Move m = new Move(t1, Color.yellow);
                            m.AddMove(origin, t1);
                            m.AddMove(t, t2);
                            moves.Add(m);
                        }
                        else if (t.unit != null)
                        {
                            t = null;
                        }
                    }
                } while (t != null);
            }
        }
        return moves;
    }
}
