﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour {

    public int x, y;
    public bool white;
    public bool hasMoved;
    public bool isMoving;
    public Board board;

    Material material;

    private void Awake()
    {
        x = y = -1;
        isMoving = false;
    }

    public void SetColor(bool white)
    {
        this.white = white;
        name = (white ? "White_" : "Black_") + GetType().Name;
        GetComponent<MeshRenderer>().material.color = white ? Color.blue : Color.red;
    }

    private void OnMouseUp()
    {
        board.TileClicked(board.GetTile(x,y));
    }

    //Returns: 0 = move, 1 = kill, 2 = promotion
    public virtual int MoveTo(Board board, Tile tile, float speed = 1f)
    {
        hasMoved = true;
        int i = 1;
        if (tile.unit != null)
        {
            board.Kill(tile.unit);
            i = 2;
        }
        Tile t = board.GetTile(x, y);
        if (t != null)
        {
            t.unit = null;
        }
        x = tile.x;
        y = tile.y;
        tile.unit = this;
        StartCoroutine(MoveTowards(tile.transform.localPosition + new Vector3(0, .5f, 0), speed));
        return i;
    }

    private IEnumerator MoveTowards(Vector3 target, float s)
    {
        isMoving = true;
        float speed = Vector3.Distance(transform.localPosition, target) * s * 2;
        while (!transform.localPosition.Equals(target))
        {
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, target, speed * Time.deltaTime);
            yield return new WaitForSeconds(0.01f);
        }
        isMoving = false;
    }

    public bool CanMove(Tile tile)
    {
        if (tile == null)
        {
            return false;
        }
        if (tile.unit == null)
        {
            return true;
        }
        return tile.unit.white != white;
    }
    /*
    public virtual Tile[] GetMoves(Board board)
    {
        return null;
    }
    */

    public virtual List<Move> GetMoves(Board board)
    {
        return null;
    }
}
