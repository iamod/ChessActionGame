﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pawn : Unit {

    public override List<Move> GetMoves(Board board)
    {
        List<Move> moves = new List<Move>();
        Tile origin = board.GetTile(x, y);
        //Move forward
        Tile t = board.GetTile(x, y + (white ? 1 : -1));
        if (t.unit == null)
        {
            Move m = null;
            if (IsPromotionTile(t)) {
                m = new Move(t, Color.yellow, 3);
            }
            else
            {
                m = new Move(t, Color.green);
            }
            m.AddMove(origin, t);
            moves.Add(m);

            if (!hasMoved)
            {
                t = board.GetTile(x, y + (white ? 2 : -2));
                if (t != null && t.unit == null)
                {
                    Move m2 = new Move(t, IsPromotionTile(t) ? Color.yellow : Color.green);
                    m2.AddMove(origin, t);
                    moves.Add(m2);
                }
            }
        }
        //Attack sideways
        t = board.GetTile(x + 1, y + (white ? 1 : -1));
        if (t != null && t.unit != null && t.unit.white != white)
        {
            Move m = new Move(t, Color.red);
            m.AddMove(origin, t);
            moves.Add(m);
        }

        t = board.GetTile(x + -1, y + (white ? 1 : -1));
        if (t != null && t.unit != null && t.unit.white != white)
        {
            Move m = new Move(t, Color.red);
            m.AddMove(origin, t);
            moves.Add(m);
        }
        return moves;
    }

    public override int MoveTo(Board board, Tile tile, float speed = 1f)
    {
        int i = base.MoveTo(board, tile, speed);
        if ((white && y == board.height - 1) || (!white && y == 0))
        {
            Debug.Log(this + " promoted!" + x + ", " + y);
            return 3;
        }
        return i;
    }

    private bool IsPromotionTile(Tile t)
    {
        return (white && t.y == board.height - 1) || (!white && t.y == 0);
    }
}