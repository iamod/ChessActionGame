﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "simpleAI", menuName = "AI/simpleAI")]
public class AI : ScriptableObject {

	public Move GetMove(Board board, List<Unit> aiArmy) {
        List<Move> moves = new List<Move>();
        foreach (Unit u in aiArmy)
        {
            List<Move> unitMoves = u.GetMoves(board);
            if (unitMoves != null)
            {
                moves.AddRange(unitMoves);
            }
        }
        return moves[Random.Range(0, moves.Count)];
    }
}
