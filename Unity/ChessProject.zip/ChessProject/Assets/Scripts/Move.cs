﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move {

    public Tile triggerTile;
    private List<Tile> tiles;
    public Color color;
    int result;

    public Move(Tile triggerTile, Color color, int i = 1)
    {
        tiles = new List<Tile>();
        this.triggerTile = triggerTile;
        this.color = color;
        result = i;
    }

    public void AddMove(Tile t1, Tile t2)
    {
        tiles.Add(t1);
        tiles.Add(t2);
    }

    public int PerformMoves(Board board)
    {
        for(int i = 0; i < tiles.Count; i += 2)
        {
            tiles[i].unit.MoveTo(board, tiles[i + 1]);
        }
        return result;
    }

}
