﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "KillKing", menuName = "Objectives/KillKing")]
public class KillKing : Objective
{

    public override string GetObjectiveDescription()
    {
        return "Kill enemy king";
    }

    public override int GetStatus(Board board, List<Unit> friendlyArmy, List<Unit> enemyArmy)
    {
        foreach (Unit u in enemyArmy)
        {
            if (u is King)
            {
                return 0;
            }
        }
        return 1;
    }

}