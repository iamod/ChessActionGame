﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "KillAll", menuName = "Objectives/KillAll")]
public class KillAll : Objective
{

    public override string GetObjectiveDescription()
    {
        return "Kill all enemy units";
    }

    public override int GetStatus(Board board, List<Unit> friendlyArmy, List<Unit> enemyArmy)
    {
        return enemyArmy.Count == 0 ? 1 : 0;
    }

}