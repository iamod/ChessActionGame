﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Objective : ScriptableObject {

    public virtual string GetObjectiveDescription()
    {
        return "This is a mission";
    }

    //Returns: 1 = completed, 0 = neutral, -1 = failed
    public virtual int GetStatus(Board board, List<Unit> friendlyArmy, List<Unit> enemyArmy)
    {
        return 0;
    }

}