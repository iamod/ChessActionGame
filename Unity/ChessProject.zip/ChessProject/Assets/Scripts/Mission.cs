﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Mission : MonoBehaviour {

    public int id;
    public int result;

    public int mapWidth;
    public int mapHeight;

    public Unit[] whiteUnits;
    public Vector2[] whiteSpawn;

    public Unit[] blackUnits;
    public Vector2[] blackSpawn;

    public Objective[] whiteObjectives;
    public Objective[] blackObjectives;

    Color[] colors = { Color.gray, Color.white, Color.blue };

    private void Start()
    {
        SetResult(MissionData.instance.GetResult(this));
        GetComponentInChildren<Text>().text = (id + 1).ToString();
        if (result == 0)
        {
            GetComponent<Button>().enabled = false;
        }
    }

    public void StartMission()
    {
        MissionData.instance.StartMission(this);
    }

    public void SetResult(int i)
    {
        result = i;
        GetComponent<Image>().color = colors[i];
    }

    public int GetStatus(Board board, List<Unit> whiteUnits, List<Unit> blackUnits)
    {
        int i = 1;

        foreach (Objective o in blackObjectives)
        {
            i = Mathf.Min(i, o.GetStatus(board, blackUnits, whiteUnits));
        }
        if (i != 0)
        {
            return -i;
        }

        i = 1;
        foreach (Objective o in whiteObjectives)
        {
            i = Mathf.Min(i, o.GetStatus(board, whiteUnits, blackUnits));
        }

        return i;
    }
}
