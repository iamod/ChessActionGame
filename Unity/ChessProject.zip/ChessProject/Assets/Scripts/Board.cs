﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board : MonoBehaviour {

    private TurnManager turnManager;

    public Tile tilePrefab;
    public Material[] tileMaterials;

    public Tile[] tiles;
    public int width, height;

	void Start () {
        turnManager = GetComponent<TurnManager>();
        width = MissionData.instance.mission.mapWidth;
        height = MissionData.instance.mission.mapHeight;

        //Instantiate tiles
        tiles = new Tile[width * height];
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                Tile t = tiles[y * width + x] = Instantiate(tilePrefab, new Vector3(x, 0, y), Quaternion.identity, transform);
                t.SetMaterial(tileMaterials[(x + y) % tileMaterials.Length]);
                t.transform.localPosition = new Vector3(x - 3, 0, y - height / 2 + 0.5f);
                t.x = x;
                t.y = y;
                t.name = "Tile " + x + "," + y;
                t.board = this;
            }
        }
	}

    //Checks if given coordinate is within the board
    public bool Contains(int x, int y)
    {
        return (x >= 0 && x < width && y >= 0 && y < height);
    }

    public Tile GetTile(int x, int y)
    {
        if (Contains(x,y))
        {
            return tiles[x + y * width];
        }
        return null;
    }

    public void TileClicked(Tile tile)
    {
        turnManager.TileClicked(tile);
    }

    public void ColorTiles(List<Move> moveList)
    {
        foreach (Move m in moveList){
            ColorTile(m.triggerTile, m.color);
        }
    }

    public void ColorTile(Tile tile, Color color, bool colorUnits = true)
    {
        //Red color for tiles with units in them
        if (colorUnits && tile.unit != null)
        {
            tiles[tile.x + tile.y * width].SetColor(Color.red);
        }
        else {
            tiles[tile.x + tile.y * width].SetColor(color);
        }
    }

    public void ResetColors()
    {
        foreach (Tile t in tiles)
        {
            t.ResetColor();
        }
    }

    public void Kill(Unit unit)
    {
        turnManager.UnitKilled(unit);
        GetTile(unit.x, unit.y).unit = null;
        Destroy(unit.gameObject);
    }

}