﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MissionData : MonoBehaviour {

    public static MissionData instance;

    public Mission mission;
    public int[] missionResults;
    int result;

	void Awake () {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
        }
        DontDestroyOnLoad(gameObject);
	}

    public void StartMission(Mission mission)
    {
        this.mission = Instantiate(mission, Vector3.zero, Quaternion.identity, transform);
        SceneManager.LoadScene(1);
    }

    public void ReturnToMap(int result)
    {
        int id = mission.id;
        if (result > 0 && missionResults[id] < result)
        {
            missionResults[id] = result;

            //Unlock next level
            if (id < missionResults.Length + 1 && missionResults[id + 1] == 0)
            {
                missionResults[id + 1] = 1;
            }
            
        }
        Destroy(mission);
        SceneManager.LoadScene(0);
    }

    public int GetResult(Mission mission)
    {
        return missionResults[mission.id];
    }
}
