﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TurnManager : MonoBehaviour {
    
    private Board board;
    private Unit selectedUnit;
    private List<Unit> blackUnits = new List<Unit>();
    private List<Unit> whiteUnits = new List<Unit>();
    private List<Move> moves;
    private State status;
    private bool whiteTurn;
    private Mission mission;
    private int result;
    private int turn;

    public AI ai;
    public Text text;
    public Unit promotion;

    private void Start()
    {
        board = GetComponent<Board>();
        mission = MissionData.instance.mission;

        //Spawn white army
        for (int i = 0; i < mission.whiteUnits.Length; i++)
        {
            Unit u = SpawnUnit(mission.whiteUnits[i], mission.whiteSpawn[i], true);
            whiteUnits.Add(u);
        }
        
        //Spawn black army
        for (int i = 0; i < mission.blackUnits.Length; i++)
        {
            Unit u = SpawnUnit(mission.blackUnits[i], mission.blackSpawn[i], false);
            blackUnits.Add(u);
        }

        //Wait for units to move
        status = State.WAITING;
        selectedUnit = whiteUnits[0];
        whiteTurn = true;
        turn = 1;
    }

    private Unit SpawnUnit(Unit unit, Vector2 spawn, bool white)
    {
        Unit u = Instantiate(unit, Vector3.zero, Quaternion.identity, board.transform);
        Tile t = board.GetTile((int)spawn.x, (int)spawn.y);
        u.board = board;
        u.SetColor(white);
        u.transform.localPosition = t.transform.localPosition + (white ? -1 : 1) * new Vector3(0, 0, 4);
        u.MoveTo(board, t, 0.25f);
        u.hasMoved = false;
        return u;
    }

    private void Update()
    {
        /*
        if (!whiteTurn)
        {
            Move m = ai.GetMove(board, blackUnits);
            m.Perform(board);
            NextTurn();
        }
        */
        if (selectedUnit != null)
        {
            if (status == State.WAITING && !selectedUnit.isMoving)
            {
                UnselectUnit();
                status = State.READY;
            }
            //Right mouse button unselects unit
            else if (!selectedUnit.isMoving && Input.GetMouseButtonUp(1))
            {
                UnselectUnit();
            }
        }  
        if (status == State.GAMEOVER && Input.GetMouseButtonDown(0))
        {
            MissionData.instance.ReturnToMap(result);
        }
    }

    public void TileClicked(Tile tile)
    {
        //Return if game is not waiting for player input
        if (status != State.READY)
        {
            return;
        }

        if (selectedUnit == null && tile.unit != null && tile.unit.white == whiteTurn)
        {
            SelectUnit(tile.unit);
        }
        else if (selectedUnit != null)
        {
            Move m = IsLegalMove(tile);
            if (m != null)
            {
                status = State.WAITING;
                int i = m.PerformMoves(board);
                
                if (i > 0)
                {
                    //Promotion
                    if (i == 3)
                    {
                        PromoteUnit();
                    }
                    NextTurn();
                }
            }
            else if (tile.unit != null && tile.unit.white == whiteTurn)
            {
                UnselectUnit();
                SelectUnit(tile.unit);
            }
        }
    }

    private void NextTurn()
    {
        board.ResetColors();
        whiteTurn = !whiteTurn;
        if (whiteTurn)
        {
            turn++;
        }
    }

    private void PromoteUnit()
    {
        Unit oldUnit = selectedUnit;
        selectedUnit = Instantiate(promotion, selectedUnit.transform.position, Quaternion.identity, transform);
        selectedUnit.board = board;
        selectedUnit.SetColor(oldUnit.white);
        if (selectedUnit.white)
        {
            whiteUnits.Add(selectedUnit);
        }
        else
        {
            blackUnits.Add(selectedUnit);
        }
        selectedUnit.MoveTo(board, board.GetTile((int)oldUnit.x, (int)oldUnit.y));
        Destroy(oldUnit);
    }

    private void SelectUnit(Unit unit)
    {
        selectedUnit = unit;
        moves = selectedUnit.GetMoves(board);
        board.ResetColors();
        board.ColorTile(board.GetTile(unit.x, unit.y), Color.yellow, false);
        board.ColorTiles(moves);

    }

    private void UnselectUnit()
    {
        board.ResetColors();
        selectedUnit = null;
    }

    private Move IsLegalMove(Tile tile)
    {
        foreach (Move m in moves)
        {
            if (tile == m.triggerTile)
            {
                return m;
            }
        }
        return null;
    }

    public void UnitKilled(Unit unit)
    {
        if (unit.white)
        {
            whiteUnits.Remove(unit);
        }
        else
        {
            blackUnits.Remove(unit);
        }
        if (status != State.END)
        {
            GameOver(unit);
        }
    }

    //Tests if gameOver condition is met
    private bool GameOver(Unit unit)
    {
        int i = mission.GetStatus(board, whiteUnits, blackUnits);
        if (i != 0)
        {
            Debug.Log("Game over! "+i+ " " +unit);
            text.gameObject.SetActive(true);
            status = State.END;
            if (i == 1)
            {
                text.text = "VICTORY!";
                text.color = Color.blue;
                result = 2;
                StartCoroutine(KillArmy(blackUnits));
            }
            else if (i == -1)
            {
                text.text = "DEFEATED!";
                text.color = Color.red;
                result = 0;
                StartCoroutine(KillArmy(whiteUnits));
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    //Slowly kills target army
    private IEnumerator KillArmy(List<Unit> army)
    {
        while (army.Count > 0)
        {
            Unit u = army[Random.Range(0, army.Count)];
            board.Kill(u);
            yield return new WaitForSeconds(0.5f);
        }
        yield return new WaitForSeconds(1f);
        status = State.GAMEOVER;
        yield return new WaitForSeconds(10f);
        MissionData.instance.ReturnToMap(result);
    }

    enum State
    {
        WAITING, READY, END, GAMEOVER
    };
}